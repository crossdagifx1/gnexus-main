import{j as s}from"./ui-vendor-BVsvkAYU.js";import{h as r}from"./App-CTjUVnBF.js";const a=({children:a,className:o})=>s.jsx("div",{className:r(o),children:a});export{a as A};
